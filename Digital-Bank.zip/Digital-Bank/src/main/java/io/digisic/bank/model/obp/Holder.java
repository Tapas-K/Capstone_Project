package io.digisic.bank.model.obp;

public class Holder {
	
	private String name;
	private String is_alias;

	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the is_alias
	 */
	public String getIs_alias() {
		return is_alias;
	}
	/**
	 * @param is_alias the is_alias to set
	 */
	public void setIs_alias(String is_alias) {
		this.is_alias = is_alias;
	}

}
